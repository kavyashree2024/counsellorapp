from django.contrib import admin
from .models import CounsellorInfo,AdminInfo,FinalTable

# Register your models here.

admin.site.register(CounsellorInfo)
admin.site.register(AdminInfo)
admin.site.register(FinalTable)
# admin.site.register(AdminInfo)
